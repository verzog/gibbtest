## Configuration

How to configure this app: by an admin panel.

## YunoHost specific features

#### Multi-user support

* Are LDAP and HTTP auth supported? **Yes** 
* Can the app be used by multiple users? **Yes**
